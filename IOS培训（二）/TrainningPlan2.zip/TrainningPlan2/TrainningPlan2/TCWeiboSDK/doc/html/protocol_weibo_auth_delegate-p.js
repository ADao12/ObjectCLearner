var protocol_weibo_auth_delegate_p =
[
    [ "DidAuthCanceled:", "protocol_weibo_auth_delegate-p.html#ad4b082f9b61300afa0f98996bb82bdd8", null ],
    [ "DidAuthFailWithError:", "protocol_weibo_auth_delegate-p.html#a2ef86907f2770a0cb35094118217be1b", null ],
    [ "DidAuthFinished:", "protocol_weibo_auth_delegate-p.html#a8b3dd966298b1b938e3b124ff68ee978", null ],
    [ "didCheckAuthValid:suggest:", "protocol_weibo_auth_delegate-p.html#abd712c88dd2d0c83e2298274071b6f74", null ]
];