var interface_weibo_api_object =
[
    [ "accessToken", "interface_weibo_api_object.html#a98ac26e28003e66adefaabef4d77db91", null ],
    [ "appKey", "interface_weibo_api_object.html#aa8281c99d30b29ac7743a95756e26efe", null ],
    [ "appSecret", "interface_weibo_api_object.html#a8fc605486741e2bf3dbd93dbbb395c6c", null ],
    [ "AppSSOUsable", "interface_weibo_api_object.html#a8371c0878a511a426127d6cf111af0b5", null ],
    [ "authDelegate", "interface_weibo_api_object.html#a64a2f30c0f8329fa233b015b4aaeafef", null ],
    [ "authDelegate2", "interface_weibo_api_object.html#a332739ae7ad553707f609e107d0b04bc", null ],
    [ "authMode", "interface_weibo_api_object.html#a0de8e31c4f1f95a242a6a10708467219", null ],
    [ "expires", "interface_weibo_api_object.html#ab387d82d353a4ffc326fd94284216a32", null ],
    [ "openid", "interface_weibo_api_object.html#a72964637d3ac442d44a81648d74a9112", null ],
    [ "realAuthMode", "interface_weibo_api_object.html#a3457569117c54cbae09aef85263f4b93", null ],
    [ "redirectUri", "interface_weibo_api_object.html#a92fd472287296441eabd5461dfdad10c", null ],
    [ "refreshToken", "interface_weibo_api_object.html#ab1cd2fe1cb8e81c34819f455309ef89e", null ],
    [ "reqDelegate", "interface_weibo_api_object.html#aa8f2b8a4f43bc43ccb59669d8ddbfed2", null ],
    [ "rootViewCtrl", "interface_weibo_api_object.html#adbcb3f26656ab7189e5ced7cc88829eb", null ],
    [ "systemSSOUsable", "interface_weibo_api_object.html#a153aa40d5286717cb0734c8800d428a2", null ],
    [ "userName", "interface_weibo_api_object.html#a0ad02dd1dcc8e5f44d60b82341a06f95", null ],
    [ "userNick", "interface_weibo_api_object.html#aea5130903aadc1b353674a6097a45081", null ]
];