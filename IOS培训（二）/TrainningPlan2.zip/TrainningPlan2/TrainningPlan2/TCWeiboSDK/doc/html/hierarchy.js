var hierarchy =
[
    [ "<NSCoding>", null, [
      [ "WeiboApiObject", "interface_weibo_api_object.html", null ]
    ] ],
    [ "<NSCopying>", null, [
      [ "WeiboApiObject", "interface_weibo_api_object.html", null ]
    ] ],
    [ "NSObject", null, [
      [ "WeiboApi", "interface_weibo_api.html", null ],
      [ "WeiboApiObject", "interface_weibo_api_object.html", null ]
    ] ],
    [ "<NSObject>", null, [
      [ "<WeiboRequestDelegate>", "protocol_weibo_request_delegate-p.html", null ]
    ] ],
    [ "<NSObjectNSObject>", null, [
      [ "<WeiboAuthDelegate>", "protocol_weibo_auth_delegate-p.html", null ]
    ] ]
];