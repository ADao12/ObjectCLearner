//
//  constant.h
//  TCWeiboSDK-LightVersion
//
//  Created by heloyue on 13-5-8.
//  Copyright (c) 2013年 heloyue. All rights reserved.
//

#ifndef TCWeiboSDK_LightVersion_constant_h
#define TCWeiboSDK_LightVersion_constant_h



#define WiressSDKDemoAppKey     @"801213517"
#define WiressSDKDemoAppSecret  @"9819935c0ad171df934d0ffb340a3c2d"
#define REDIRECTURI             @"http://www.ying7wang7.com"


#endif
