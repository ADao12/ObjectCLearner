##IOS学习笔记之了解xcode工程中build setting中Search Paths中的各项的含义

---
---

+ Framework search paths: 除系统框架外的其他框架的搜索路径。

+ Header search path: 头文件搜索路径设置

+ Library search path: 库搜素路径

+ User Header search path: 设置主工程依赖的外部头文件路径